package ui;

public interface CounterListener {

    public void rangeChanged(int minimum,int maximum);

    public void countChanged();

}
