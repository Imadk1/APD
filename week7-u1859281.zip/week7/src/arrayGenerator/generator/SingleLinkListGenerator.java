package arrayGenerator.generator;

import linkedList.list.ListAccessError;
import linkedList.list.SinglyLinkedList;

public interface SingleLinkListGenerator<T> {

    public SinglyLinkedList<T> getList(int size) throws NegativeArraySizeException, ListAccessError;

}