package arrayGenerator.generator;


import arrayGenerator.scope.Scope;
import linkedList.list.ListAccessError;
import linkedList.list.SinglyLinkedList;

abstract class ScopedSingleLinkListGenerator<T> implements SingleLinkListGenerator<T> {


    private Scope<Object> scope;

    public ScopedSingleLinkListGenerator(Object scope) {

    }

    abstract SinglyLinkedList<T> createList(int size) throws ListAccessError;



    T[] createArray(int size) {

        return null;

    }



    public T[] getArray(int size) throws NegativeArraySizeException {

        if (size < 0) {

            throw new NegativeArraySizeException();

        }

        T[] array = createArray(size);

        for (int i = 0; i < size; i++) {

            array[i] = (T) scope.getValue();

        }

        return array;

    }

    public SinglyLinkedList<T> getList(int size) throws ListAccessError {

        if (size < 0) {

            throw new ListAccessError(" ");

        }

        SinglyLinkedList<T> list = createList(size);

        for (int i = 0; i < size; i++) {

            list.add(i, (T) scope.getValue());

        }

        return list;

    }



}