package arrayGenerator.generator;


import arrayGenerator.scope.Scope;
import linkedList.list.ListAccessError;
import linkedList.list.SinglyLinkedList;

public class IntegerSingleLinkListGenerator extends ScopedSingleLinkListGenerator<Integer>

{



    public IntegerSingleLinkListGenerator(Scope<Integer> scope) {

        super(scope);

    }





    @Override

    SinglyLinkedList<Integer> createList(int size) throws ListAccessError {

        if (size < 1){

            throw new ListAccessError("A list must have a size > 0");

        }

        SinglyLinkedList<Integer> list = new SinglyLinkedList<>();

        Integer[] array = createArray(size);

        // Add every element of the array to the linkedlist

        for (int i = 0; i < size; i++){

            list.add(i, array[i]);

        }

        return list;

    }



    Integer[] createArray(int size) {

        return new Integer[size];

    }

}
