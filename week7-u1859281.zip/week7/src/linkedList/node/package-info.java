/**
 * Provides single and double link nodes for use in implementations of lists.
 *
 * @author Hugh Osborne
 * @version October 2019
 */
package linkedList.node;