/**
 * Defines and implements various types of list.
 *
 * @author Hugh Osborne
 * @version October 2019
 */
package linkedList.list;