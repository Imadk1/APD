package LinkedList;

import linkedList.list.ListAccessError;
import linkedList.list.SinglyLinkedList;
import timer.Timer;

public abstract class SingleLinkedListTime implements Timer {

    @Override

    public void timedMethod() {

        try {

            list.get(1);

            list.get(list.getSize()-(list.getSize()/2));

            list.get(list.getSize()-1);



        } catch (ListAccessError listAccessError) {

            listAccessError.printStackTrace();

        }

    }
}
