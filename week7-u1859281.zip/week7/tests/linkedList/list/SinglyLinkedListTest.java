package linkedList.list;

class SinglyLinkedListTest {

}