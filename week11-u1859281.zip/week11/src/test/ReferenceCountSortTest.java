package test;

import graph.GraphError;
import graph.ReferenceCountSort;

public class ReferenceCountSortTest {
    public static void main(String[] args) throws GraphError {
        int i;
        ReferenceCountSort<Integer> intGraph = new ReferenceCountSort<>();
        for (i = 0; i < 10; i++) {
            intGraph.add(i);
        }

        intGraph.add(0, 1);
        intGraph.add(0, 4);
        intGraph.add(1, 3);
        intGraph.add(1, 2);
        intGraph.add(3, 5);
        intGraph.add(2, 7);
        intGraph.add(4, 9);
        intGraph.add(4, 8);

        System.out.println(intGraph.getSort());
    }
}
