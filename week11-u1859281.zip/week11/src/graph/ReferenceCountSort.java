package graph;

import java.util.*;

/**
 *
 * @param <T>
 *
 * @author Imad Kazi.
 * @version December 2019.
 */

public class ReferenceCountSort<T> extends AdjacencyGraph<T> implements TopologicalSort<T> {

    Stack<T> sort;
    Set<T> visiting = new HashSet<T>();
    private HashMap<T, Integer> referencesCount = new HashMap<T, Integer>();

    @Override

    public List<T> getSort() throws GraphError {
        sort = new Stack<T>();
        setUpReferenceCounts();
        doSort();
        return sort;
    }

    private void setUpReferenceCounts() throws GraphError {

        for (T node : getNodes()) {
            referencesCount.put(node, 0);
        }

        for (T node : getNodes()) {
            for (T neighbour : getNeighbours(node)) {
                increaseReferenceCount(neighbour);
            }
        }
    }


    private void visitNode(T node) throws GraphError {
        if (sort.contains(node)) {
            return;
        }
        if (visiting.contains(node)) {
            throw new GraphError("Cannot get topological sort.  Graph is not acyclic.");
        }
        visiting.add(node);
        for (T neighbour : getNeighbours(node)) {
            decreaseReferenceCount(neighbour);
            visitNode(neighbour);
        }
        sort.push(node);
        visiting.remove(node);
        referencesCount.remove(node);
    }

    private void doSort() throws GraphError {
        T node;
        while ((node = nextReferenceZeroNode()) != null) {
            visitNode(node);
        }
    }

    private T nextReferenceZeroNode() {
        Integer value = null;
        for (Map.Entry<T, Integer> entry : referencesCount.entrySet()) {
            if (entry.getValue() == 0) {
                return (T) entry.getKey();
            }
        }
        return null;
    }

    private void decreaseReferenceCount(T neighbour) {
        Integer count = referencesCount.get(neighbour);
        if (count != null) {
            referencesCount.put(neighbour, count--);
        }
    }

    private void increaseReferenceCount(T neighbour) {
        Integer count = referencesCount.get(neighbour);
        if (count == null) {
            count = 1;
        } else {
            count++;
        }
        referencesCount.put(neighbour, count);
    }
}