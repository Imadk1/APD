package arraySorter;

public class SelectionSort <T extends Comparable<? super T>> implements ArraySort<T> {

    public T[] sort(T[] array) {

        int length = array.length;


        for (int i = 0; i < length -1; i++){

            int min = i;
            for (int j = i+1; j < length; j++)
                if (array[j].compareTo(array[min]) < 0 )
                    min = j;

            T t = array[min];
            array[min] = array[i];
            array[i] = t;
        }

        return array;
    }
}
