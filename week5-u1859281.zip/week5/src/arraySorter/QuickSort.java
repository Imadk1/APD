package arraySorter;

public class QuickSort<T extends Comparable<? super T>> implements ArraySort<T> {
    public T[] sort(T[] array)
    {
        Quicksort(array, 0, array.length -1);
        return array;
    }
    public void Quicksort(T[] array, int a, int b){

        if (a < b) {
            int i = a, j = b;
            T x = array[(i + j) / 2];

            do {
                while (array[i].compareTo(x) < 0) i++;
                while (x.compareTo(array[j]) < 0) j--;

                if (i <= j) {
                    T tmp = array[i];
                    array[i] = array[j];
                    array[j] = tmp;
                    i++;
                    j--;
                }

            } while (i <= j);

            Quicksort(array, a, j);
            Quicksort(array, i, b);

        }

    }
}
