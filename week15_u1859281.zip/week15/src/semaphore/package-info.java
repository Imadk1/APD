/**
 * Various semaphore implementations.  All should implement the SemaphoreInterface.
 *
 * @author Hugh Osborne
 * @version January 2020
 */
package semaphore;