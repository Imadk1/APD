/**
 * An implementation of bounded buffers using semaphores to protect buffer access.
 *
 * @author Hugh Osborne
 * @version January 2020
 */
package boundedBuffer;