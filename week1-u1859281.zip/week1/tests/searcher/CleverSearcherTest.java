package searcher;

import arrayGenerator.ListingGeneratorTest;

/**
 * @author Imad Kazi
 * @version September 2019
 */

class CleverSearcherTest extends SearcherTest {

    protected Searcher createSearcher(int[] array, int index) throws IndexingError {
        return new CleverSearcher(array,index);
    }

}