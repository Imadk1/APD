package searcher;



public class CleverSearcher extends Searcher {

    /**

     * This searcher sorts various elements smaller than it into a separate array

     * The length of the smaller array is subtracted from the original array to return the index of the element

     * @param array array being searched

     * @param k index being searched for

     */

    CleverSearcher(int[] array, int k) {

        super(array, k);

    }



    public int findElement() throws IndexingError {

        int[] array = getArray();

        int k = getIndex();

        if (k <= 0 || k > array.length) {

            throw new IndexingError();

        }

        // create new array with only k in it

        int[] smallArray = new int[k];

        smallArray[0] = k;



        // for each remaining element of the main array

        for (int index = 0; index < array.length; index++) {

            // If element is smaller than smallest element of small array

            if (array[index] < smallArray[0]) {

                // replace smallest element

                array[index] = smallArray[0];

            }

        }



        return array.length - smallArray.length;

    }

}