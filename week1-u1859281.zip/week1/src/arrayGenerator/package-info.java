/**
 * ArrayGenerators are objects that generate arrays of integers.
 *
 * @author Hugh Osborne
 * @version September 2019
 */

package arrayGenerator;
