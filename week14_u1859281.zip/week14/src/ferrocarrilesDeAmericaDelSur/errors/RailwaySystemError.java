package ferrocarrilesDeAmericaDelSur.errors;

/**
 * A general class of errrors for railway systems.
 */
public class RailwaySystemError extends Exception {
	public RailwaySystemError(String message) {
		super(message);
	}
}
