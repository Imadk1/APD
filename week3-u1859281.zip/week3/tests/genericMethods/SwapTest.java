package genericMethods;

import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertFalse;

class SwapTest {
    @Test
    void test1() {

        Integer[] array = {4, 3, 2, 5, 1, 6, 9};
        Integer[] array2 = {4, 3, 9, 5, 1, 6, 2};;
        assertArrayEquals(array2, (Swap.swap(array, 2, 6)));

    }



}