package genericMethods;

public class Swap {

    static <T> T[] swap(T[] array, int index1, int index2) {
        T t = array[index1];
        array[index1] = array[index2];
        array[index2] = t;
        return array;
    }
}
