package graph;

import java.util.ArrayList;
import java.util.List;

public class DepthFirstTraversal<T> extends AdjacencyGraph<T> implements Traversal<T> {

    private List<T> traversal = new ArrayList<T>();
    private List<T> backtrackList = new ArrayList<T>();

    /**
     *
     * Perform a depth first traversal of the graph and return a list of nodes
     * in the order in which they are visited.
     * @return a depth first traversal of the graph
     */
    @Override
    public List<T> traverse() throws GraphError {
        T node = getUnvisitedNode();
        while (node != null) {
            visitNode(node);
            node = getUnvisitedNeighbour(node);
            if (node == null && !backtrackList.isEmpty())
                node = backtrack();
        }
        return traversal;
    }


    /**
     * Visit a node. Adds node to traversal and backtrack lists
     * if node has been visited, return
     *
     */
    private void visitNode(T node) {
        if (visited(node)) return;
        traversal.add(node);
        backtrackList.add(node);
    }

    /**
     *
     * backtrack the list until any unvisited neighbours are found
     * @return any unvisited neighbour nodes
     * @throws GraphError if the node is not a node in the graph
     */
    private T backtrack() throws GraphError {
        while (backtrackList.size() > 1){
            T node = backtrackList.get(backtrackList.size() -2);
            backtrackList.remove(backtrackList.size() -1);
            if (getUnvisitedNeighbour(node) !=null ){
                return getUnvisitedNeighbour(node);
            }
        }
        return null; // return null if there are no unvisited neighbours remaining
    }

    /**
     * Check if a node has been visited
     *
     * @return this node has been visited
     */
    private boolean visited(T node) {
        return
                traversal.contains(node); // the node has been visited and is in the traversal list
    }

    /**
     * Get the next "unvisited" node.
     *
     * @return a node that has not yet been visited, or return null if no such node exists
     */
    private T getUnvisitedNode() {
        for (T node: getNodes()) {
            if (!visited(node)) {
                return node;
            }
        }

        return null;
    }

    /**
     * Get the next "unvisited" neighbour node.
     *
     * @param node the node being checked for unvisited neighbours
     * @return a neighbouring node that has not yet been visited, or return null if no such node exists
     * @throws GraphError if the node is not a node in the graph
     */

    private T getUnvisitedNeighbour(T node) throws GraphError {
        for (T neighbour: getNeighbours(node)) {
            if (!visited(neighbour)) {
                return neighbour;
            }
        }

        return null;
    }
}
